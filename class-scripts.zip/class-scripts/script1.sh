#!/bin/bash
# This is a comment
echo "Hello, World!" #prints "Hello, World!" to the terminal
 
