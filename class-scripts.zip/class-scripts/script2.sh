#!/bin/bash

greeting="Hello"
name="World"

echo "$greeting, $name!"
