#!/bin/bash

echo "The script name is $0"
echo "The first argument is $1"
echo "The number of arguments is $#"
